//app.js
App({
  onLaunch: function () {
    setTimeout(function () {
      wx.hideLoading()
    }, 2000)
    //初始化云
    wx.cloud.init({
      env: "xueshi-0hsp9"
    })
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        console.log("log success")
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        this.getOpenid()

    
      }
    })
    //获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          console.log("authorisation")
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              //确认是否有未读消息
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.wxUserInfo = res.userInfo
              this.globalData.hasLogin = true
              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
        else{
          console.log("no authorisation")
        }
      }
    })
  },
  onShow:function(){
   
  },
  getOpenid() {
    wx.cloud.callFunction({
      name: 'getOpenid',
      success: res => {
        console.log('openid--', res.result.openid)
        var openid = res.result.openid
        this.globalData.openid = openid
        if(this.globalData.hasLogin)
          this.checkRedDot("applications")
      }
    })
  },
  
  globalData: {
    wxUserInfo: null,
    openid: null,
    hasLogin:false
  },
  checkRedDot(database) {
    wx.cloud.callFunction({
      name: "getUserMessages",
      data: {
        openid: this.globalData.openid,
        databaseName: database
      },
      success: res => {
        // console.log("get messages successfully", res.result.data)
        if (res.result.data.length > 0) {
          var datasets = res.result.data;
          console.log(datasets)
          for(var index=0; index < datasets.length; index++){
            if(datasets[index].toRead){
              wx.showTabBarRedDot({
                index: 2,
              })
              break
            }
          }
          // console.log(this.data);
        } else {
          console.log("no messages")
        }
      },
      fail: res => {
        console.log("get messages from database failed", res)
      }
    })
  },
})