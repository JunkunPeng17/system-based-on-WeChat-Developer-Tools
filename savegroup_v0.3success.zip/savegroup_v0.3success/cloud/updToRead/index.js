// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "xueshi-0hsp9"
})

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  return await cloud.database().collection(event.databasename).doc(event.msgid).update({
    data: {
      toRead: false
    },
    success: console.log,
    fail: console.error
  })
}